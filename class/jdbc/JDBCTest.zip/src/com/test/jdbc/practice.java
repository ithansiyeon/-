package com.test.jdbc;

public class practice {
	public static void main(String[] args) {
		
		for(int i=0;i<12;i++) {
			System.out.printf("update tblopenCourse set status = 0 where num = %d;\r\n",i+1);
		}
	}

}
